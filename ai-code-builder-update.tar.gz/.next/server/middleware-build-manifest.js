globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/5bcee453cc4bce6d.js",
    "static/chunks/82abf2d65f5428ae.js",
    "static/chunks/f2f58a7e93290fbb.js",
    "static/chunks/ad0eb8f7a09fbec7.js",
    "static/chunks/turbopack-8fd6a4168d30f428.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];