var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/projects/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__48ad0d0e._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/[root-of-the-server]__d30e337c._.js")
R.c("server/chunks/[root-of-the-server]__29144969._.js")
R.c("server/chunks/[root-of-the-server]__24f8fcd9._.js")
R.c("server/chunks/_next-internal_server_app_api_projects_[id]_route_actions_6fd2e5a5.js")
R.m(40252)
module.exports=R.m(40252).exports
