var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/socket/route.js")
R.c("server/chunks/[externals]__a0203fa4._.js")
R.c("server/chunks/[root-of-the-server]__db5a931e._.js")
R.c("server/chunks/[root-of-the-server]__599e5945._.js")
R.c("server/chunks/[root-of-the-server]__d2be59c9._.js")
R.c("server/chunks/[root-of-the-server]__24f8fcd9._.js")
R.c("server/chunks/_next-internal_server_app_api_socket_route_actions_4dd9c19f.js")
R.m(5319)
module.exports=R.m(5319).exports
