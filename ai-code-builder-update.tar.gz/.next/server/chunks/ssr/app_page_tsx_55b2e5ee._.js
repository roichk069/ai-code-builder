module.exports=[60350,a=>{"use strict";var b=a.i(87924),c=a.i(38246),d=a.i(72131);let e=[{id:"landing-page",name:"Landing Page",description:"Modern landing page with hero section, features, and CTA",files:{"/index.html":`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modern Landing Page</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900 text-white">
    <nav class="container mx-auto px-6 py-6 flex justify-between items-center">
        <div class="text-2xl font-bold">YourBrand</div>
        <div class="space-x-6">
            <a href="#features" class="hover:text-purple-300">Features</a>
            <a href="#pricing" class="hover:text-purple-300">Pricing</a>
            <a href="#contact" class="hover:text-purple-300">Contact</a>
        </div>
    </nav>

    <section class="container mx-auto px-6 py-24 text-center">
        <h1 class="text-6xl font-bold mb-6">Build Something Amazing</h1>
        <p class="text-xl mb-12 text-purple-200">The ultimate platform to bring your ideas to life</p>
        <button class="bg-white text-purple-900 px-8 py-4 rounded-full text-lg font-semibold hover:bg-purple-100 transition">
            Get Started Free
        </button>
    </section>

    <section id="features" class="container mx-auto px-6 py-24">
        <h2 class="text-4xl font-bold text-center mb-16">Features</h2>
        <div class="grid md:grid-cols-3 gap-12">
            <div class="text-center">
                <div class="text-5xl mb-4">⚡</div>
                <h3 class="text-2xl font-bold mb-4">Lightning Fast</h3>
                <p class="text-purple-200">Blazing fast performance for the best user experience</p>
            </div>
            <div class="text-center">
                <div class="text-5xl mb-4">🔒</div>
                <h3 class="text-2xl font-bold mb-4">Secure</h3>
                <p class="text-purple-200">Enterprise-grade security to keep your data safe</p>
            </div>
            <div class="text-center">
                <div class="text-5xl mb-4">🎨</div>
                <h3 class="text-2xl font-bold mb-4">Beautiful</h3>
                <p class="text-purple-200">Stunning design that your users will love</p>
            </div>
        </div>
    </section>

    <section class="container mx-auto px-6 py-24 text-center">
        <h2 class="text-4xl font-bold mb-6">Ready to get started?</h2>
        <p class="text-xl mb-12 text-purple-200">Join thousands of happy customers</p>
        <button class="bg-white text-purple-900 px-8 py-4 rounded-full text-lg font-semibold hover:bg-purple-100 transition">
            Start Your Free Trial
        </button>
    </section>
</body>
</html>`}},{id:"blog",name:"Blog",description:"Clean blog layout with posts and sidebar",files:{"/index.html":`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Blog</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <nav class="bg-white shadow-sm">
        <div class="container mx-auto px-6 py-4">
            <div class="flex justify-between items-center">
                <h1 class="text-2xl font-bold text-gray-800">My Blog</h1>
                <div class="space-x-6">
                    <a href="#" class="text-gray-600 hover:text-gray-900">Home</a>
                    <a href="#" class="text-gray-600 hover:text-gray-900">About</a>
                    <a href="#" class="text-gray-600 hover:text-gray-900">Contact</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-6 py-12">
        <div class="grid md:grid-cols-3 gap-8">
            <div class="md:col-span-2 space-y-8">
                <article class="bg-white rounded-lg shadow-md overflow-hidden">
                    <img src="https://via.placeholder.com/800x400" alt="Post" class="w-full">
                    <div class="p-6">
                        <div class="text-sm text-gray-500 mb-2">June 1, 2024</div>
                        <h2 class="text-3xl font-bold mb-4">Getting Started with Web Development</h2>
                        <p class="text-gray-700 mb-4">
                            Learn the fundamentals of web development and build your first website. 
                            This comprehensive guide will walk you through HTML, CSS, and JavaScript basics.
                        </p>
                        <a href="#" class="text-blue-600 hover:text-blue-800 font-semibold">Read More →</a>
                    </div>
                </article>

                <article class="bg-white rounded-lg shadow-md overflow-hidden">
                    <img src="https://via.placeholder.com/800x400" alt="Post" class="w-full">
                    <div class="p-6">
                        <div class="text-sm text-gray-500 mb-2">May 28, 2024</div>
                        <h2 class="text-3xl font-bold mb-4">10 Design Tips for Beginners</h2>
                        <p class="text-gray-700 mb-4">
                            Master the art of web design with these essential tips that will help 
                            you create beautiful and functional websites.
                        </p>
                        <a href="#" class="text-blue-600 hover:text-blue-800 font-semibold">Read More →</a>
                    </div>
                </article>
            </div>

            <aside>
                <div class="bg-white rounded-lg shadow-md p-6 mb-8">
                    <h3 class="text-xl font-bold mb-4">About Me</h3>
                    <p class="text-gray-700">
                        Hi! I'm a web developer passionate about creating amazing digital experiences.
                    </p>
                </div>

                <div class="bg-white rounded-lg shadow-md p-6">
                    <h3 class="text-xl font-bold mb-4">Categories</h3>
                    <ul class="space-y-2">
                        <li><a href="#" class="text-gray-600 hover:text-gray-900">Web Development</a></li>
                        <li><a href="#" class="text-gray-600 hover:text-gray-900">Design</a></li>
                        <li><a href="#" class="text-gray-600 hover:text-gray-900">JavaScript</a></li>
                        <li><a href="#" class="text-gray-600 hover:text-gray-900">Tutorials</a></li>
                    </ul>
                </div>
            </aside>
        </div>
    </div>
</body>
</html>`}},{id:"dashboard",name:"Dashboard",description:"Admin dashboard with charts and statistics",files:{"/index.html":`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <!-- Sidebar -->
        <aside class="w-64 bg-gray-900 text-white">
            <div class="p-6">
                <h1 class="text-2xl font-bold">Dashboard</h1>
            </div>
            <nav class="mt-6">
                <a href="#" class="block px-6 py-3 bg-gray-800">Overview</a>
                <a href="#" class="block px-6 py-3 hover:bg-gray-800">Analytics</a>
                <a href="#" class="block px-6 py-3 hover:bg-gray-800">Users</a>
                <a href="#" class="block px-6 py-3 hover:bg-gray-800">Settings</a>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="flex-1 overflow-y-auto">
            <header class="bg-white shadow-sm">
                <div class="px-8 py-4">
                    <h2 class="text-2xl font-bold text-gray-800">Overview</h2>
                </div>
            </header>

            <div class="p-8">
                <!-- Stats Grid -->
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                    <div class="bg-white rounded-lg shadow p-6">
                        <div class="text-sm text-gray-500">Total Users</div>
                        <div class="text-3xl font-bold text-gray-900 mt-2">12,543</div>
                        <div class="text-sm text-green-600 mt-2">↑ 12% from last month</div>
                    </div>
                    <div class="bg-white rounded-lg shadow p-6">
                        <div class="text-sm text-gray-500">Revenue</div>
                        <div class="text-3xl font-bold text-gray-900 mt-2">$54,231</div>
                        <div class="text-sm text-green-600 mt-2">↑ 8% from last month</div>
                    </div>
                    <div class="bg-white rounded-lg shadow p-6">
                        <div class="text-sm text-gray-500">Active Projects</div>
                        <div class="text-3xl font-bold text-gray-900 mt-2">48</div>
                        <div class="text-sm text-gray-600 mt-2">→ No change</div>
                    </div>
                    <div class="bg-white rounded-lg shadow p-6">
                        <div class="text-sm text-gray-500">Conversion Rate</div>
                        <div class="text-3xl font-bold text-gray-900 mt-2">3.24%</div>
                        <div class="text-sm text-red-600 mt-2">↓ 2% from last month</div>
                    </div>
                </div>

                <!-- Recent Activity -->
                <div class="bg-white rounded-lg shadow p-6">
                    <h3 class="text-xl font-bold mb-4">Recent Activity</h3>
                    <table class="w-full">
                        <thead>
                            <tr class="text-left border-b">
                                <th class="pb-3">User</th>
                                <th class="pb-3">Action</th>
                                <th class="pb-3">Date</th>
                                <th class="pb-3">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr class="border-b">
                                <td class="py-3">John Doe</td>
                                <td class="py-3">Created new project</td>
                                <td class="py-3">2 hours ago</td>
                                <td class="py-3"><span class="px-2 py-1 bg-green-100 text-green-800 rounded-full text-sm">Success</span></td>
                            </tr>
                            <tr class="border-b">
                                <td class="py-3">Jane Smith</td>
                                <td class="py-3">Updated profile</td>
                                <td class="py-3">5 hours ago</td>
                                <td class="py-3"><span class="px-2 py-1 bg-green-100 text-green-800 rounded-full text-sm">Success</span></td>
                            </tr>
                            <tr class="border-b">
                                <td class="py-3">Bob Johnson</td>
                                <td class="py-3">Deleted item</td>
                                <td class="py-3">1 day ago</td>
                                <td class="py-3"><span class="px-2 py-1 bg-red-100 text-red-800 rounded-full text-sm">Deleted</span></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</body>
</html>`}},{id:"blank",name:"Blank Canvas",description:"Start from scratch with a blank HTML page",files:{"/index.html":`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Project</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <div class="container mx-auto px-6 py-12">
        <h1 class="text-4xl font-bold text-gray-900 mb-4">Hello World!</h1>
        <p class="text-gray-600">Start building something amazing...</p>
    </div>
</body>
</html>`}}];var f=a.i(68515),g=a.i(8406);function h(){let{loadTemplate:a}=(0,f.useStore)();return(0,b.jsx)("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-6",children:e.map(c=>(0,b.jsx)("button",{onClick:()=>{a(c.files)},className:"group text-left p-6 bg-slate-800 rounded-lg border border-white/10 hover:border-purple-500/50 hover:bg-slate-800/80 transition-all",children:(0,b.jsxs)("div",{className:"flex items-start gap-3",children:[(0,b.jsx)(g.Sparkles,{className:"w-6 h-6 text-purple-400 flex-shrink-0 mt-1"}),(0,b.jsxs)("div",{children:[(0,b.jsx)("h3",{className:"text-lg font-semibold text-white group-hover:text-purple-300 transition-colors",children:c.name}),(0,b.jsx)("p",{className:"text-sm text-gray-400 mt-1",children:c.description})]})]})},c.id))})}var i=a.i(54074),j=a.i(1027),k=a.i(70106);let l=(0,k.default)("panels-top-left",[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}],["path",{d:"M3 9h18",key:"1pudct"}],["path",{d:"M9 21V9",key:"1oto5p"}]]),m=(0,k.default)("arrow-right",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]]),n=(0,k.default)("github",[["path",{d:"M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4",key:"tonef"}],["path",{d:"M9 18c-4.51 2-5-2-7-2",key:"9comsn"}]]);var o=a.i(72857),p=a.i(40695);function q(){let[a,e]=(0,d.useState)(!1);return(0,b.jsxs)("div",{className:"min-h-screen bg-slate-950 gradient-mesh overflow-hidden",children:[(0,b.jsxs)("div",{className:"absolute inset-0 overflow-hidden pointer-events-none",children:[(0,b.jsx)("div",{className:"absolute top-20 left-10 w-72 h-72 bg-purple-500/10 rounded-full blur-3xl animate-pulse-slow"}),(0,b.jsx)("div",{className:"absolute bottom-20 right-10 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse-slow",style:{animationDelay:"1s"}}),(0,b.jsx)("div",{className:"absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[40rem] h-[40rem] bg-purple-500/5 rounded-full blur-3xl animate-pulse-slow",style:{animationDelay:"2s"}})]}),(0,b.jsxs)("nav",{className:"relative container mx-auto px-6 py-6 flex justify-between items-center",children:[(0,b.jsxs)("div",{className:"flex items-center gap-3",children:[(0,b.jsx)("div",{className:"w-10 h-10 rounded-lg bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center",children:(0,b.jsx)(g.Sparkles,{className:"w-5 h-5 text-white"})}),(0,b.jsx)("span",{className:"text-2xl font-bold text-white",children:"AI Code Builder"})]}),(0,b.jsxs)("div",{className:"flex items-center gap-4",children:[(0,b.jsx)("a",{href:"https://github.com/roichk069/ai-code-builder",target:"_blank",rel:"noopener noreferrer",className:"text-gray-400 hover:text-white transition-smooth",children:(0,b.jsx)(n,{className:"w-6 h-6"})}),(0,b.jsx)(c.default,{href:"/editor",children:(0,b.jsx)(p.Button,{className:"bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 btn-hover",children:"Open Editor"})})]})]}),(0,b.jsxs)("div",{className:"relative container mx-auto px-6 py-24 text-center",children:[(0,b.jsxs)("div",{className:"inline-flex items-center gap-2 px-4 py-2 glass rounded-full text-purple-300 text-sm mb-8 animate-fadeIn",children:[(0,b.jsx)(g.Sparkles,{className:"w-4 h-4 animate-pulse-slow"}),(0,b.jsx)("span",{className:"font-medium",children:"AI-Powered Code Generation"})]}),(0,b.jsxs)("h1",{className:"text-5xl sm:text-6xl md:text-7xl font-bold text-white mb-6 leading-tight animate-fadeIn",children:["Build Websites with",(0,b.jsx)("br",{}),(0,b.jsx)("span",{className:"text-gradient",children:"Natural Language"})]}),(0,b.jsx)("p",{className:"text-lg sm:text-xl text-gray-300 mb-12 max-w-3xl mx-auto leading-relaxed animate-fadeIn",children:"Describe what you want to build in plain English, and watch AI generate complete, production-ready code with live preview in seconds."}),(0,b.jsxs)("div",{className:"flex flex-col sm:flex-row gap-4 justify-center items-center animate-fadeIn",children:[(0,b.jsx)(c.default,{href:"/editor",children:(0,b.jsxs)(p.Button,{size:"lg",className:"bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-lg px-8 py-6 btn-hover glow-purple",children:["Start Building Free",(0,b.jsx)(m,{className:"w-5 h-5 ml-2"})]})}),(0,b.jsxs)(p.Button,{size:"lg",variant:"outline",className:"text-lg px-8 py-6 glass hover:bg-white/10 btn-hover",onClick:()=>e(!a),children:[(0,b.jsx)(l,{className:"w-5 h-5 mr-2"}),"Browse Templates"]})]}),(0,b.jsxs)("div",{className:"mt-20 rounded-2xl overflow-hidden glass shadow-2xl max-w-5xl mx-auto animate-fadeIn",children:[(0,b.jsxs)("div",{className:"bg-slate-900/80 backdrop-blur-sm p-4 border-b border-white/10 flex items-center gap-3",children:[(0,b.jsxs)("div",{className:"flex gap-2",children:[(0,b.jsx)("div",{className:"w-3 h-3 rounded-full bg-red-500/80"}),(0,b.jsx)("div",{className:"w-3 h-3 rounded-full bg-yellow-500/80"}),(0,b.jsx)("div",{className:"w-3 h-3 rounded-full bg-green-500/80"})]}),(0,b.jsxs)("div",{className:"flex items-center gap-2 text-gray-400 text-sm",children:[(0,b.jsx)(o.Monitor,{className:"w-4 h-4"}),(0,b.jsx)("span",{children:"AI Code Builder"})]})]}),(0,b.jsx)("div",{className:"bg-gradient-to-br from-slate-900 to-slate-800 p-12",children:(0,b.jsxs)("div",{className:"grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 max-w-4xl mx-auto",children:[(0,b.jsxs)("div",{className:"glass p-6 rounded-xl hover:scale-105 transition-smooth",children:[(0,b.jsx)("div",{className:"w-12 h-12 rounded-lg bg-gradient-to-br from-purple-500 to-purple-600 flex items-center justify-center mb-4",children:(0,b.jsx)(g.Sparkles,{className:"w-6 h-6 text-white"})}),(0,b.jsx)("h3",{className:"text-white font-semibold mb-2",children:"AI Chat"}),(0,b.jsx)("p",{className:"text-gray-400 text-sm",children:"Natural language interface"})]}),(0,b.jsxs)("div",{className:"glass p-6 rounded-xl hover:scale-105 transition-smooth",children:[(0,b.jsx)("div",{className:"w-12 h-12 rounded-lg bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center mb-4",children:(0,b.jsx)(i.Code,{className:"w-6 h-6 text-white"})}),(0,b.jsx)("h3",{className:"text-white font-semibold mb-2",children:"Live Editor"}),(0,b.jsx)("p",{className:"text-gray-400 text-sm",children:"Monaco code editor"})]}),(0,b.jsxs)("div",{className:"glass p-6 rounded-xl hover:scale-105 transition-smooth",children:[(0,b.jsx)("div",{className:"w-12 h-12 rounded-lg bg-gradient-to-br from-green-500 to-green-600 flex items-center justify-center mb-4",children:(0,b.jsx)(j.Zap,{className:"w-6 h-6 text-white"})}),(0,b.jsx)("h3",{className:"text-white font-semibold mb-2",children:"Live Preview"}),(0,b.jsx)("p",{className:"text-gray-400 text-sm",children:"Real-time rendering"})]})]})})]})]}),a&&(0,b.jsxs)("div",{className:"relative container mx-auto px-6 pb-24 animate-fadeIn",children:[(0,b.jsx)("h2",{className:"text-4xl font-bold text-white text-center mb-12",children:"Quick Start Templates"}),(0,b.jsx)(h,{}),(0,b.jsx)("div",{className:"text-center mt-8",children:(0,b.jsx)(c.default,{href:"/editor",children:(0,b.jsxs)(p.Button,{className:"bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 btn-hover",children:["Start with a Template",(0,b.jsx)(m,{className:"w-4 h-4 ml-2"})]})})})]}),(0,b.jsxs)("div",{className:"relative container mx-auto px-6 py-24",children:[(0,b.jsx)("h2",{className:"text-4xl font-bold text-white text-center mb-16",children:"Everything You Need to Build Fast"}),(0,b.jsx)("div",{className:"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6",children:[{icon:(0,b.jsx)(g.Sparkles,{className:"w-6 h-6"}),title:"AI Code Generation",description:"Generate complete, working code from natural language descriptions",color:"from-purple-500 to-purple-600"},{icon:(0,b.jsx)(i.Code,{className:"w-6 h-6"}),title:"Monaco Editor",description:"VS Code-powered editor with syntax highlighting and IntelliSense",color:"from-blue-500 to-blue-600"},{icon:(0,b.jsx)(j.Zap,{className:"w-6 h-6"}),title:"Live Preview",description:"See your changes instantly with real-time preview",color:"from-green-500 to-green-600"},{icon:(0,b.jsx)(l,{className:"w-6 h-6"}),title:"Multiple Files",description:"Create and manage complex projects with multiple files",color:"from-orange-500 to-orange-600"},{icon:(0,b.jsx)(o.Monitor,{className:"w-6 h-6"}),title:"Beautiful Templates",description:"Start with professionally designed templates",color:"from-pink-500 to-pink-600"},{icon:(0,b.jsx)(m,{className:"w-6 h-6"}),title:"Export & Deploy",description:"Download your project or deploy with one click",color:"from-indigo-500 to-indigo-600"}].map((a,c)=>(0,b.jsxs)("div",{className:"glass p-6 rounded-xl hover:scale-105 transition-smooth card animate-fadeIn",style:{animationDelay:`${.1*c}s`},children:[(0,b.jsx)("div",{className:`w-12 h-12 rounded-lg bg-gradient-to-br ${a.color} flex items-center justify-center mb-4 text-white`,children:a.icon}),(0,b.jsx)("h3",{className:"text-xl font-semibold text-white mb-2",children:a.title}),(0,b.jsx)("p",{className:"text-gray-400 leading-relaxed",children:a.description})]},c))})]}),(0,b.jsx)("div",{className:"relative container mx-auto px-6 py-24 text-center",children:(0,b.jsxs)("div",{className:"max-w-3xl mx-auto glass-strong p-12 rounded-3xl",children:[(0,b.jsx)("h2",{className:"text-4xl sm:text-5xl font-bold text-white mb-6",children:"Ready to Start Building?"}),(0,b.jsx)("p",{className:"text-xl text-gray-300 mb-8 leading-relaxed",children:"No credit card required. Start creating amazing websites today."}),(0,b.jsx)(c.default,{href:"/editor",children:(0,b.jsxs)(p.Button,{size:"lg",className:"bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-lg px-12 py-6 btn-hover glow-purple",children:["Get Started Free",(0,b.jsx)(m,{className:"w-5 h-5 ml-2"})]})})]})}),(0,b.jsx)("footer",{className:"relative border-t border-white/10 py-8 backdrop-blur-sm",children:(0,b.jsxs)("div",{className:"container mx-auto px-6 text-center text-gray-400",children:[(0,b.jsx)("p",{children:"Built with ❤️ using Next.js, TypeScript, and AI"}),(0,b.jsx)("p",{className:"text-sm mt-2",children:(0,b.jsx)("a",{href:"https://github.com/roichk069/ai-code-builder",target:"_blank",rel:"noopener noreferrer",className:"hover:text-purple-400 transition-colors",children:"View on GitHub"})})]})})]})}a.s(["default",()=>q],60350)}];

//# sourceMappingURL=app_page_tsx_55b2e5ee._.js.map