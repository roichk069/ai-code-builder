(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,33525,(e,t,s)=>{"use strict";Object.defineProperty(s,"__esModule",{value:!0}),Object.defineProperty(s,"warnOnce",{enumerable:!0,get:function(){return a}});let a=e=>{}},75254,58472,e=>{"use strict";var t=e.i(71645);let s=(...e)=>e.filter((e,t,s)=>!!e&&""!==e.trim()&&s.indexOf(e)===t).join(" ").trim(),a=e=>{let t=e.replace(/^([A-Z])|[\s-_]+(\w)/g,(e,t,s)=>s?s.toUpperCase():t.toLowerCase());return t.charAt(0).toUpperCase()+t.slice(1)};var l={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};let r=(0,t.forwardRef)(({color:e="currentColor",size:a=24,strokeWidth:r=2,absoluteStrokeWidth:i,className:o="",children:n,iconNode:d,...c},h)=>(0,t.createElement)("svg",{ref:h,...l,width:a,height:a,stroke:e,strokeWidth:i?24*Number(r)/Number(a):r,className:s("lucide",o),...!n&&!(e=>{for(let t in e)if(t.startsWith("aria-")||"role"===t||"title"===t)return!0;return!1})(c)&&{"aria-hidden":"true"},...c},[...d.map(([e,s])=>(0,t.createElement)(e,s)),...Array.isArray(n)?n:[n]])),i=(e,l)=>{let i=(0,t.forwardRef)(({className:i,...o},n)=>(0,t.createElement)(r,{ref:n,iconNode:l,className:s(`lucide-${a(e).replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase()}`,`lucide-${e}`,i),...o}));return i.displayName=a(e),i};e.s(["default",()=>i],75254);let o=i("code",[["path",{d:"m16 18 6-6-6-6",key:"eg8j8"}],["path",{d:"m8 6-6 6 6 6",key:"ppft3o"}]]);e.s(["Code",()=>o],58472)},4421,83086,e=>{"use strict";let t,s,a,l;var r,i=e.i(71645);let o=e=>{let t,s=new Set,a=(e,a)=>{let l="function"==typeof e?e(t):e;if(!Object.is(l,t)){let e=t;t=(null!=a?a:"object"!=typeof l||null===l)?l:Object.assign({},t,l),s.forEach(s=>s(t,e))}},l=()=>t,r={setState:a,getState:l,getInitialState:()=>i,subscribe:e=>(s.add(e),()=>s.delete(e))},i=t=e(a,l,r);return r};function n(e,t){let s;try{s=e()}catch(e){return}return{getItem:e=>{var a;let l=e=>null===e?null:JSON.parse(e,null==t?void 0:t.reviver),r=null!=(a=s.getItem(e))?a:null;return r instanceof Promise?r.then(l):l(r)},setItem:(e,a)=>s.setItem(e,JSON.stringify(a,null==t?void 0:t.replacer)),removeItem:e=>s.removeItem(e)}}let d=e=>t=>{try{let s=e(t);if(s instanceof Promise)return s;return{then:e=>d(e)(s),catch(e){return this}}}catch(e){return{then(e){return this},catch:t=>d(t)(e)}}};class c{files=new Map;setFile(e,t){this.files.set(e,t)}getFile(e){return this.files.get(e)}deleteFile(e){this.files.delete(e)}getAllFiles(){return new Map(this.files)}getFileTree(){let e={name:"root",path:"/",type:"directory",children:[]};return Array.from(this.files.keys()).sort().forEach(t=>{let s=t.split("/").filter(Boolean),a=e;s.forEach((e,t)=>{let l=t===s.length-1,r="/"+s.slice(0,t+1).join("/");a.children||(a.children=[]);let i=a.children.find(t=>t.name===e);i||(i={name:e,path:r,type:l?"file":"directory",children:l?void 0:[]},a.children.push(i)),a=i})}),e}clear(){this.files.clear()}setFiles(e){this.files=new Map(e)}}let h=(a=(r=(t=(e,t)=>({vfs:new c,currentFile:null,setCurrentFile:t=>e({currentFile:t}),updateFile:(s,a)=>{let{vfs:l}=t();l.setFile(s,a),e({vfs:new c,previewKey:t().previewKey+1}),t().vfs.setFiles(l.getAllFiles())},deleteFile:s=>{let{vfs:a,currentFile:l}=t();a.deleteFile(s),e({vfs:new c,currentFile:l===s?null:l}),t().vfs.setFiles(a.getAllFiles())},loadTemplate:s=>{let{vfs:a}=t();a.clear(),Object.entries(s).forEach(([e,t])=>{a.setFile(e,t)}),e({vfs:new c,currentFile:"/index.html",previewKey:t().previewKey+1}),t().vfs.setFiles(a.getAllFiles())},messages:[],addMessage:t=>e(e=>({messages:[...e.messages,{...t,id:Math.random().toString(36).substr(2,9),timestamp:Date.now()}]})),clearMessages:()=>e({messages:[]}),consoleLogs:[],addConsoleLog:t=>e(e=>({consoleLogs:[...e.consoleLogs,{...t,id:Math.random().toString(36).substr(2,9),timestamp:Date.now()}]})),clearConsole:()=>e({consoleLogs:[]}),isGenerating:!1,setIsGenerating:t=>e({isGenerating:t}),previewKey:0,refreshPreview:()=>e(e=>({previewKey:e.previewKey+1})),apiKey:"",setApiKey:t=>e({apiKey:t}),selectedModel:"anthropic/claude-3.5-sonnet",setSelectedModel:t=>e({selectedModel:t}),hasSeenWelcome:!1,setHasSeenWelcome:t=>e({hasSeenWelcome:t})}),s={name:"ai-code-builder-storage",storage:n(()=>localStorage),partialize:e=>({apiKey:e.apiKey,selectedModel:e.selectedModel,hasSeenWelcome:e.hasSeenWelcome})},(e,a,l)=>{let r,i={storage:n(()=>window.localStorage),partialize:e=>e,version:0,merge:(e,t)=>({...t,...e}),...s},o=!1,c=0,h=new Set,m=new Set,x=i.storage;if(!x)return t((...t)=>{console.warn(`[zustand persist middleware] Unable to update item '${i.name}', the given storage is currently unavailable.`),e(...t)},a,l);let p=()=>{let e=i.partialize({...a()});return x.setItem(i.name,{state:e,version:i.version})},u=l.setState;l.setState=(e,t)=>(u(e,t),p());let g=t((...t)=>(e(...t),p()),a,l);l.getInitialState=()=>g;let v=()=>{var t,s;if(!x)return;let l=++c;o=!1,h.forEach(e=>{var t;return e(null!=(t=a())?t:g)});let n=(null==(s=i.onRehydrateStorage)?void 0:s.call(i,null!=(t=a())?t:g))||void 0;return d(x.getItem.bind(x))(i.name).then(e=>{if(e)if("number"!=typeof e.version||e.version===i.version)return[!1,e.state];else{if(i.migrate){let t=i.migrate(e.state,e.version);return t instanceof Promise?t.then(e=>[!0,e]):[!0,t]}console.error("State loaded from storage couldn't be migrated since no migrate function was provided")}return[!1,void 0]}).then(t=>{var s;if(l!==c)return;let[o,n]=t;if(e(r=i.merge(n,null!=(s=a())?s:g),!0),o)return p()}).then(()=>{l===c&&(null==n||n(r,void 0),r=a(),o=!0,m.forEach(e=>e(r)))}).catch(e=>{l===c&&(null==n||n(void 0,e))})};return l.persist={setOptions:e=>{i={...i,...e},e.storage&&(x=e.storage)},clearStorage:()=>{null==x||x.removeItem(i.name)},getOptions:()=>i,rehydrate:()=>v(),hasHydrated:()=>o,onHydrate:e=>(h.add(e),()=>{h.delete(e)}),onFinishHydration:e=>(m.add(e),()=>{m.delete(e)})},i.skipHydration||v(),r||g}))?o(r):o,Object.assign(l=e=>(function(e,t=e=>e){let s=i.default.useSyncExternalStore(e.subscribe,i.default.useCallback(()=>t(e.getState()),[e,t]),i.default.useCallback(()=>t(e.getInitialState()),[e,t]));return i.default.useDebugValue(s),s})(a,e),a),l);e.s(["useStore",0,h],4421);let m=(0,e.i(75254).default)("sparkles",[["path",{d:"M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z",key:"1s2grr"}],["path",{d:"M20 2v4",key:"1rf3ol"}],["path",{d:"M22 4h-4",key:"gwowj6"}],["circle",{cx:"4",cy:"20",r:"2",key:"6kqj1y"}]]);e.s(["Sparkles",()=>m],83086)},39312,e=>{"use strict";let t=(0,e.i(75254).default)("zap",[["path",{d:"M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",key:"1xq2db"}]]);e.s(["Zap",()=>t],39312)},51445,e=>{"use strict";let t=(0,e.i(75254).default)("monitor",[["rect",{width:"20",height:"14",x:"2",y:"3",rx:"2",key:"48i651"}],["line",{x1:"8",x2:"16",y1:"21",y2:"21",key:"1svkeh"}],["line",{x1:"12",x2:"12",y1:"17",y2:"21",key:"vw1qmm"}]]);e.s(["Monitor",()=>t],51445)},31713,e=>{"use strict";var t=e.i(43476),s=e.i(22016),a=e.i(71645);let l=[{id:"landing-page",name:"Landing Page",description:"Modern landing page with hero section, features, and CTA",files:{"/index.html":`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modern Landing Page</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900 text-white">
    <nav class="container mx-auto px-6 py-6 flex justify-between items-center">
        <div class="text-2xl font-bold">YourBrand</div>
        <div class="space-x-6">
            <a href="#features" class="hover:text-purple-300">Features</a>
            <a href="#pricing" class="hover:text-purple-300">Pricing</a>
            <a href="#contact" class="hover:text-purple-300">Contact</a>
        </div>
    </nav>

    <section class="container mx-auto px-6 py-24 text-center">
        <h1 class="text-6xl font-bold mb-6">Build Something Amazing</h1>
        <p class="text-xl mb-12 text-purple-200">The ultimate platform to bring your ideas to life</p>
        <button class="bg-white text-purple-900 px-8 py-4 rounded-full text-lg font-semibold hover:bg-purple-100 transition">
            Get Started Free
        </button>
    </section>

    <section id="features" class="container mx-auto px-6 py-24">
        <h2 class="text-4xl font-bold text-center mb-16">Features</h2>
        <div class="grid md:grid-cols-3 gap-12">
            <div class="text-center">
                <div class="text-5xl mb-4">⚡</div>
                <h3 class="text-2xl font-bold mb-4">Lightning Fast</h3>
                <p class="text-purple-200">Blazing fast performance for the best user experience</p>
            </div>
            <div class="text-center">
                <div class="text-5xl mb-4">🔒</div>
                <h3 class="text-2xl font-bold mb-4">Secure</h3>
                <p class="text-purple-200">Enterprise-grade security to keep your data safe</p>
            </div>
            <div class="text-center">
                <div class="text-5xl mb-4">🎨</div>
                <h3 class="text-2xl font-bold mb-4">Beautiful</h3>
                <p class="text-purple-200">Stunning design that your users will love</p>
            </div>
        </div>
    </section>

    <section class="container mx-auto px-6 py-24 text-center">
        <h2 class="text-4xl font-bold mb-6">Ready to get started?</h2>
        <p class="text-xl mb-12 text-purple-200">Join thousands of happy customers</p>
        <button class="bg-white text-purple-900 px-8 py-4 rounded-full text-lg font-semibold hover:bg-purple-100 transition">
            Start Your Free Trial
        </button>
    </section>
</body>
</html>`}},{id:"blog",name:"Blog",description:"Clean blog layout with posts and sidebar",files:{"/index.html":`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Blog</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <nav class="bg-white shadow-sm">
        <div class="container mx-auto px-6 py-4">
            <div class="flex justify-between items-center">
                <h1 class="text-2xl font-bold text-gray-800">My Blog</h1>
                <div class="space-x-6">
                    <a href="#" class="text-gray-600 hover:text-gray-900">Home</a>
                    <a href="#" class="text-gray-600 hover:text-gray-900">About</a>
                    <a href="#" class="text-gray-600 hover:text-gray-900">Contact</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-6 py-12">
        <div class="grid md:grid-cols-3 gap-8">
            <div class="md:col-span-2 space-y-8">
                <article class="bg-white rounded-lg shadow-md overflow-hidden">
                    <img src="https://via.placeholder.com/800x400" alt="Post" class="w-full">
                    <div class="p-6">
                        <div class="text-sm text-gray-500 mb-2">June 1, 2024</div>
                        <h2 class="text-3xl font-bold mb-4">Getting Started with Web Development</h2>
                        <p class="text-gray-700 mb-4">
                            Learn the fundamentals of web development and build your first website. 
                            This comprehensive guide will walk you through HTML, CSS, and JavaScript basics.
                        </p>
                        <a href="#" class="text-blue-600 hover:text-blue-800 font-semibold">Read More →</a>
                    </div>
                </article>

                <article class="bg-white rounded-lg shadow-md overflow-hidden">
                    <img src="https://via.placeholder.com/800x400" alt="Post" class="w-full">
                    <div class="p-6">
                        <div class="text-sm text-gray-500 mb-2">May 28, 2024</div>
                        <h2 class="text-3xl font-bold mb-4">10 Design Tips for Beginners</h2>
                        <p class="text-gray-700 mb-4">
                            Master the art of web design with these essential tips that will help 
                            you create beautiful and functional websites.
                        </p>
                        <a href="#" class="text-blue-600 hover:text-blue-800 font-semibold">Read More →</a>
                    </div>
                </article>
            </div>

            <aside>
                <div class="bg-white rounded-lg shadow-md p-6 mb-8">
                    <h3 class="text-xl font-bold mb-4">About Me</h3>
                    <p class="text-gray-700">
                        Hi! I'm a web developer passionate about creating amazing digital experiences.
                    </p>
                </div>

                <div class="bg-white rounded-lg shadow-md p-6">
                    <h3 class="text-xl font-bold mb-4">Categories</h3>
                    <ul class="space-y-2">
                        <li><a href="#" class="text-gray-600 hover:text-gray-900">Web Development</a></li>
                        <li><a href="#" class="text-gray-600 hover:text-gray-900">Design</a></li>
                        <li><a href="#" class="text-gray-600 hover:text-gray-900">JavaScript</a></li>
                        <li><a href="#" class="text-gray-600 hover:text-gray-900">Tutorials</a></li>
                    </ul>
                </div>
            </aside>
        </div>
    </div>
</body>
</html>`}},{id:"dashboard",name:"Dashboard",description:"Admin dashboard with charts and statistics",files:{"/index.html":`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <!-- Sidebar -->
        <aside class="w-64 bg-gray-900 text-white">
            <div class="p-6">
                <h1 class="text-2xl font-bold">Dashboard</h1>
            </div>
            <nav class="mt-6">
                <a href="#" class="block px-6 py-3 bg-gray-800">Overview</a>
                <a href="#" class="block px-6 py-3 hover:bg-gray-800">Analytics</a>
                <a href="#" class="block px-6 py-3 hover:bg-gray-800">Users</a>
                <a href="#" class="block px-6 py-3 hover:bg-gray-800">Settings</a>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="flex-1 overflow-y-auto">
            <header class="bg-white shadow-sm">
                <div class="px-8 py-4">
                    <h2 class="text-2xl font-bold text-gray-800">Overview</h2>
                </div>
            </header>

            <div class="p-8">
                <!-- Stats Grid -->
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                    <div class="bg-white rounded-lg shadow p-6">
                        <div class="text-sm text-gray-500">Total Users</div>
                        <div class="text-3xl font-bold text-gray-900 mt-2">12,543</div>
                        <div class="text-sm text-green-600 mt-2">↑ 12% from last month</div>
                    </div>
                    <div class="bg-white rounded-lg shadow p-6">
                        <div class="text-sm text-gray-500">Revenue</div>
                        <div class="text-3xl font-bold text-gray-900 mt-2">$54,231</div>
                        <div class="text-sm text-green-600 mt-2">↑ 8% from last month</div>
                    </div>
                    <div class="bg-white rounded-lg shadow p-6">
                        <div class="text-sm text-gray-500">Active Projects</div>
                        <div class="text-3xl font-bold text-gray-900 mt-2">48</div>
                        <div class="text-sm text-gray-600 mt-2">→ No change</div>
                    </div>
                    <div class="bg-white rounded-lg shadow p-6">
                        <div class="text-sm text-gray-500">Conversion Rate</div>
                        <div class="text-3xl font-bold text-gray-900 mt-2">3.24%</div>
                        <div class="text-sm text-red-600 mt-2">↓ 2% from last month</div>
                    </div>
                </div>

                <!-- Recent Activity -->
                <div class="bg-white rounded-lg shadow p-6">
                    <h3 class="text-xl font-bold mb-4">Recent Activity</h3>
                    <table class="w-full">
                        <thead>
                            <tr class="text-left border-b">
                                <th class="pb-3">User</th>
                                <th class="pb-3">Action</th>
                                <th class="pb-3">Date</th>
                                <th class="pb-3">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr class="border-b">
                                <td class="py-3">John Doe</td>
                                <td class="py-3">Created new project</td>
                                <td class="py-3">2 hours ago</td>
                                <td class="py-3"><span class="px-2 py-1 bg-green-100 text-green-800 rounded-full text-sm">Success</span></td>
                            </tr>
                            <tr class="border-b">
                                <td class="py-3">Jane Smith</td>
                                <td class="py-3">Updated profile</td>
                                <td class="py-3">5 hours ago</td>
                                <td class="py-3"><span class="px-2 py-1 bg-green-100 text-green-800 rounded-full text-sm">Success</span></td>
                            </tr>
                            <tr class="border-b">
                                <td class="py-3">Bob Johnson</td>
                                <td class="py-3">Deleted item</td>
                                <td class="py-3">1 day ago</td>
                                <td class="py-3"><span class="px-2 py-1 bg-red-100 text-red-800 rounded-full text-sm">Deleted</span></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</body>
</html>`}},{id:"blank",name:"Blank Canvas",description:"Start from scratch with a blank HTML page",files:{"/index.html":`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Project</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <div class="container mx-auto px-6 py-12">
        <h1 class="text-4xl font-bold text-gray-900 mb-4">Hello World!</h1>
        <p class="text-gray-600">Start building something amazing...</p>
    </div>
</body>
</html>`}}];var r=e.i(4421),i=e.i(83086);function o(){let{loadTemplate:e}=(0,r.useStore)();return(0,t.jsx)("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-6",children:l.map(s=>(0,t.jsx)("button",{onClick:()=>{e(s.files)},className:"group text-left p-6 bg-slate-800 rounded-lg border border-white/10 hover:border-purple-500/50 hover:bg-slate-800/80 transition-all",children:(0,t.jsxs)("div",{className:"flex items-start gap-3",children:[(0,t.jsx)(i.Sparkles,{className:"w-6 h-6 text-purple-400 flex-shrink-0 mt-1"}),(0,t.jsxs)("div",{children:[(0,t.jsx)("h3",{className:"text-lg font-semibold text-white group-hover:text-purple-300 transition-colors",children:s.name}),(0,t.jsx)("p",{className:"text-sm text-gray-400 mt-1",children:s.description})]})]})},s.id))})}var n=e.i(58472),d=e.i(39312),c=e.i(75254);let h=(0,c.default)("panels-top-left",[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}],["path",{d:"M3 9h18",key:"1pudct"}],["path",{d:"M9 21V9",key:"1oto5p"}]]),m=(0,c.default)("arrow-right",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]]),x=(0,c.default)("github",[["path",{d:"M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4",key:"tonef"}],["path",{d:"M9 18c-4.51 2-5-2-7-2",key:"9comsn"}]]);var p=e.i(51445),u=e.i(67881);function g(){let[e,l]=(0,a.useState)(!1);return(0,t.jsxs)("div",{className:"min-h-screen bg-slate-950 gradient-mesh overflow-hidden",children:[(0,t.jsxs)("div",{className:"absolute inset-0 overflow-hidden pointer-events-none",children:[(0,t.jsx)("div",{className:"absolute top-20 left-10 w-72 h-72 bg-purple-500/10 rounded-full blur-3xl animate-pulse-slow"}),(0,t.jsx)("div",{className:"absolute bottom-20 right-10 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse-slow",style:{animationDelay:"1s"}}),(0,t.jsx)("div",{className:"absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[40rem] h-[40rem] bg-purple-500/5 rounded-full blur-3xl animate-pulse-slow",style:{animationDelay:"2s"}})]}),(0,t.jsxs)("nav",{className:"relative container mx-auto px-6 py-6 flex justify-between items-center",children:[(0,t.jsxs)("div",{className:"flex items-center gap-3",children:[(0,t.jsx)("div",{className:"w-10 h-10 rounded-lg bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center",children:(0,t.jsx)(i.Sparkles,{className:"w-5 h-5 text-white"})}),(0,t.jsx)("span",{className:"text-2xl font-bold text-white",children:"AI Code Builder"})]}),(0,t.jsxs)("div",{className:"flex items-center gap-4",children:[(0,t.jsx)("a",{href:"https://github.com/roichk069/ai-code-builder",target:"_blank",rel:"noopener noreferrer",className:"text-gray-400 hover:text-white transition-smooth",children:(0,t.jsx)(x,{className:"w-6 h-6"})}),(0,t.jsx)(s.default,{href:"/editor",children:(0,t.jsx)(u.Button,{className:"bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 btn-hover",children:"Open Editor"})})]})]}),(0,t.jsxs)("div",{className:"relative container mx-auto px-6 py-24 text-center",children:[(0,t.jsxs)("div",{className:"inline-flex items-center gap-2 px-4 py-2 glass rounded-full text-purple-300 text-sm mb-8 animate-fadeIn",children:[(0,t.jsx)(i.Sparkles,{className:"w-4 h-4 animate-pulse-slow"}),(0,t.jsx)("span",{className:"font-medium",children:"AI-Powered Code Generation"})]}),(0,t.jsxs)("h1",{className:"text-5xl sm:text-6xl md:text-7xl font-bold text-white mb-6 leading-tight animate-fadeIn",children:["Build Websites with",(0,t.jsx)("br",{}),(0,t.jsx)("span",{className:"text-gradient",children:"Natural Language"})]}),(0,t.jsx)("p",{className:"text-lg sm:text-xl text-gray-300 mb-12 max-w-3xl mx-auto leading-relaxed animate-fadeIn",children:"Describe what you want to build in plain English, and watch AI generate complete, production-ready code with live preview in seconds."}),(0,t.jsxs)("div",{className:"flex flex-col sm:flex-row gap-4 justify-center items-center animate-fadeIn",children:[(0,t.jsx)(s.default,{href:"/editor",children:(0,t.jsxs)(u.Button,{size:"lg",className:"bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-lg px-8 py-6 btn-hover glow-purple",children:["Start Building Free",(0,t.jsx)(m,{className:"w-5 h-5 ml-2"})]})}),(0,t.jsxs)(u.Button,{size:"lg",variant:"outline",className:"text-lg px-8 py-6 glass hover:bg-white/10 btn-hover",onClick:()=>l(!e),children:[(0,t.jsx)(h,{className:"w-5 h-5 mr-2"}),"Browse Templates"]})]}),(0,t.jsxs)("div",{className:"mt-20 rounded-2xl overflow-hidden glass shadow-2xl max-w-5xl mx-auto animate-fadeIn",children:[(0,t.jsxs)("div",{className:"bg-slate-900/80 backdrop-blur-sm p-4 border-b border-white/10 flex items-center gap-3",children:[(0,t.jsxs)("div",{className:"flex gap-2",children:[(0,t.jsx)("div",{className:"w-3 h-3 rounded-full bg-red-500/80"}),(0,t.jsx)("div",{className:"w-3 h-3 rounded-full bg-yellow-500/80"}),(0,t.jsx)("div",{className:"w-3 h-3 rounded-full bg-green-500/80"})]}),(0,t.jsxs)("div",{className:"flex items-center gap-2 text-gray-400 text-sm",children:[(0,t.jsx)(p.Monitor,{className:"w-4 h-4"}),(0,t.jsx)("span",{children:"AI Code Builder"})]})]}),(0,t.jsx)("div",{className:"bg-gradient-to-br from-slate-900 to-slate-800 p-12",children:(0,t.jsxs)("div",{className:"grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 max-w-4xl mx-auto",children:[(0,t.jsxs)("div",{className:"glass p-6 rounded-xl hover:scale-105 transition-smooth",children:[(0,t.jsx)("div",{className:"w-12 h-12 rounded-lg bg-gradient-to-br from-purple-500 to-purple-600 flex items-center justify-center mb-4",children:(0,t.jsx)(i.Sparkles,{className:"w-6 h-6 text-white"})}),(0,t.jsx)("h3",{className:"text-white font-semibold mb-2",children:"AI Chat"}),(0,t.jsx)("p",{className:"text-gray-400 text-sm",children:"Natural language interface"})]}),(0,t.jsxs)("div",{className:"glass p-6 rounded-xl hover:scale-105 transition-smooth",children:[(0,t.jsx)("div",{className:"w-12 h-12 rounded-lg bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center mb-4",children:(0,t.jsx)(n.Code,{className:"w-6 h-6 text-white"})}),(0,t.jsx)("h3",{className:"text-white font-semibold mb-2",children:"Live Editor"}),(0,t.jsx)("p",{className:"text-gray-400 text-sm",children:"Monaco code editor"})]}),(0,t.jsxs)("div",{className:"glass p-6 rounded-xl hover:scale-105 transition-smooth",children:[(0,t.jsx)("div",{className:"w-12 h-12 rounded-lg bg-gradient-to-br from-green-500 to-green-600 flex items-center justify-center mb-4",children:(0,t.jsx)(d.Zap,{className:"w-6 h-6 text-white"})}),(0,t.jsx)("h3",{className:"text-white font-semibold mb-2",children:"Live Preview"}),(0,t.jsx)("p",{className:"text-gray-400 text-sm",children:"Real-time rendering"})]})]})})]})]}),e&&(0,t.jsxs)("div",{className:"relative container mx-auto px-6 pb-24 animate-fadeIn",children:[(0,t.jsx)("h2",{className:"text-4xl font-bold text-white text-center mb-12",children:"Quick Start Templates"}),(0,t.jsx)(o,{}),(0,t.jsx)("div",{className:"text-center mt-8",children:(0,t.jsx)(s.default,{href:"/editor",children:(0,t.jsxs)(u.Button,{className:"bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 btn-hover",children:["Start with a Template",(0,t.jsx)(m,{className:"w-4 h-4 ml-2"})]})})})]}),(0,t.jsxs)("div",{className:"relative container mx-auto px-6 py-24",children:[(0,t.jsx)("h2",{className:"text-4xl font-bold text-white text-center mb-16",children:"Everything You Need to Build Fast"}),(0,t.jsx)("div",{className:"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6",children:[{icon:(0,t.jsx)(i.Sparkles,{className:"w-6 h-6"}),title:"AI Code Generation",description:"Generate complete, working code from natural language descriptions",color:"from-purple-500 to-purple-600"},{icon:(0,t.jsx)(n.Code,{className:"w-6 h-6"}),title:"Monaco Editor",description:"VS Code-powered editor with syntax highlighting and IntelliSense",color:"from-blue-500 to-blue-600"},{icon:(0,t.jsx)(d.Zap,{className:"w-6 h-6"}),title:"Live Preview",description:"See your changes instantly with real-time preview",color:"from-green-500 to-green-600"},{icon:(0,t.jsx)(h,{className:"w-6 h-6"}),title:"Multiple Files",description:"Create and manage complex projects with multiple files",color:"from-orange-500 to-orange-600"},{icon:(0,t.jsx)(p.Monitor,{className:"w-6 h-6"}),title:"Beautiful Templates",description:"Start with professionally designed templates",color:"from-pink-500 to-pink-600"},{icon:(0,t.jsx)(m,{className:"w-6 h-6"}),title:"Export & Deploy",description:"Download your project or deploy with one click",color:"from-indigo-500 to-indigo-600"}].map((e,s)=>(0,t.jsxs)("div",{className:"glass p-6 rounded-xl hover:scale-105 transition-smooth card animate-fadeIn",style:{animationDelay:`${.1*s}s`},children:[(0,t.jsx)("div",{className:`w-12 h-12 rounded-lg bg-gradient-to-br ${e.color} flex items-center justify-center mb-4 text-white`,children:e.icon}),(0,t.jsx)("h3",{className:"text-xl font-semibold text-white mb-2",children:e.title}),(0,t.jsx)("p",{className:"text-gray-400 leading-relaxed",children:e.description})]},s))})]}),(0,t.jsx)("div",{className:"relative container mx-auto px-6 py-24 text-center",children:(0,t.jsxs)("div",{className:"max-w-3xl mx-auto glass-strong p-12 rounded-3xl",children:[(0,t.jsx)("h2",{className:"text-4xl sm:text-5xl font-bold text-white mb-6",children:"Ready to Start Building?"}),(0,t.jsx)("p",{className:"text-xl text-gray-300 mb-8 leading-relaxed",children:"No credit card required. Start creating amazing websites today."}),(0,t.jsx)(s.default,{href:"/editor",children:(0,t.jsxs)(u.Button,{size:"lg",className:"bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-lg px-12 py-6 btn-hover glow-purple",children:["Get Started Free",(0,t.jsx)(m,{className:"w-5 h-5 ml-2"})]})})]})}),(0,t.jsx)("footer",{className:"relative border-t border-white/10 py-8 backdrop-blur-sm",children:(0,t.jsxs)("div",{className:"container mx-auto px-6 text-center text-gray-400",children:[(0,t.jsx)("p",{children:"Built with ❤️ using Next.js, TypeScript, and AI"}),(0,t.jsx)("p",{className:"text-sm mt-2",children:(0,t.jsx)("a",{href:"https://github.com/roichk069/ai-code-builder",target:"_blank",rel:"noopener noreferrer",className:"hover:text-purple-400 transition-colors",children:"View on GitHub"})})]})})]})}e.s(["default",()=>g],31713)}]);